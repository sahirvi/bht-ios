//
//  RPN_CalculatorApp.swift
//  RPN Calculator
//
//  Created by sahi on 01.11.21.
//

import SwiftUI

@main
struct RPN_CalculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
